--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

-- Started on 2021-03-15 18:03:48 CET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 203 (class 1259 OID 16386)
-- Name: anatentity; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE anatentity (
    anatentityid character varying(20) NOT NULL,
    anatentityname character varying(255) NOT NULL,
    anatentitydescription text
);




--
-- TOC entry 3313 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN anatentity.anatentityid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN anatentity.anatentityid IS 'Anatomical entity id';


--
-- TOC entry 3314 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN anatentity.anatentityname; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN anatentity.anatentityname IS 'Anatomical entity name';


--
-- TOC entry 3315 (class 0 OID 0)
-- Dependencies: 203
-- Name: COLUMN anatentity.anatentitydescription; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN anatentity.anatentitydescription IS 'Anatomical entity description';


--
-- TOC entry 205 (class 1259 OID 16394)
-- Name: gene; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE gene (
    bgeegeneid integer NOT NULL,
    geneid character varying(20) NOT NULL,
    genename character varying(255) DEFAULT ''::character varying NOT NULL,
    genedescription text,
    speciesid integer NOT NULL
);




--
-- TOC entry 3316 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN gene.bgeegeneid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN gene.bgeegeneid IS 'Numeric internal gene ID used for improving performances';


--
-- TOC entry 3317 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN gene.geneid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN gene.geneid IS 'Real gene id';


--
-- TOC entry 3318 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN gene.genename; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN gene.genename IS 'Gene name';


--
-- TOC entry 3319 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN gene.genedescription; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN gene.genedescription IS 'Gene description';


--
-- TOC entry 3320 (class 0 OID 0)
-- Dependencies: 205
-- Name: COLUMN gene.speciesid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN gene.speciesid IS 'NCBI species taxon id this gene belongs to';


--
-- TOC entry 204 (class 1259 OID 16392)
-- Name: gene_bgeegeneid_seq; Type: SEQUENCE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE SEQUENCE gene_bgeegeneid_seq
    
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;




--
-- TOC entry 3321 (class 0 OID 0)
-- Dependencies: 204
-- Name: gene_bgeegeneid_seq; Type: SEQUENCE OWNED BY; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER SEQUENCE gene_bgeegeneid_seq OWNED BY gene.bgeegeneid;


--
-- TOC entry 207 (class 1259 OID 16404)
-- Name: globalcond; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE globalcond (
    globalconditionid integer NOT NULL,
    anatentityid character varying(20),
    stageid character varying(20),
    speciesid integer NOT NULL
);




--
-- TOC entry 3322 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN globalcond.anatentityid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalcond.anatentityid IS 'Uberon anatomical entity ID. Can be null in this table if this condition aggregates data according to other condition parameters (e.g., grouping all data in a same stage whatever the organ is).';


--
-- TOC entry 3323 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN globalcond.stageid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalcond.stageid IS 'Uberon stage ID. Can be null in this table if this condition aggregates data according to other condition parameters (e.g., grouping all data in a same organ whatever the dev. stage is).';


--
-- TOC entry 3324 (class 0 OID 0)
-- Dependencies: 207
-- Name: COLUMN globalcond.speciesid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalcond.speciesid IS 'NCBI species taxon ID';


--
-- TOC entry 206 (class 1259 OID 16402)
-- Name: globalcond_globalconditionid_seq; Type: SEQUENCE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE SEQUENCE globalcond_globalconditionid_seq
    
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;




--
-- TOC entry 3325 (class 0 OID 0)
-- Dependencies: 206
-- Name: globalcond_globalconditionid_seq; Type: SEQUENCE OWNED BY; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER SEQUENCE globalcond_globalconditionid_seq OWNED BY globalcond.globalconditionid;


--
-- TOC entry 209 (class 1259 OID 16410)
-- Name: globalexpression; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE globalexpression (
    globalexpressionid bigint NOT NULL,
    bgeegeneid integer NOT NULL,
    globalconditionid integer NOT NULL,
    summaryquality character varying(10) NOT NULL,
    rank numeric(9,2) NOT NULL,
    score numeric(9,5) NOT NULL,
    propagationorigin character varying(20) NOT NULL,
    calltype character varying(20) NOT NULL
);




--
-- TOC entry 3326 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.globalexpressionid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.globalexpressionid IS 'Internal expression ID, not stable between releases.';


--
-- TOC entry 3327 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.bgeegeneid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.bgeegeneid IS 'Internal gene ID, not stable between releases.';


--
-- TOC entry 3328 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.globalconditionid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.globalconditionid IS 'ID of condition in the related condition table ("globalCond"), not stable between releases.';


--
-- TOC entry 3329 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.rank; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.rank IS 'Normalized rank for this gene-condition after normalization over all data types, conditions and species';


--
-- TOC entry 3330 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.score; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.score IS 'Use the minimum and maximum rank of the species to normalize the expression to a value between 0 and 100';


--
-- TOC entry 3331 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.propagationorigin; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.propagationorigin IS 'The origin of the propagated expression calls : self, self and descendant, self and ancestor, or all';


--
-- TOC entry 3332 (class 0 OID 0)
-- Dependencies: 209
-- Name: COLUMN globalexpression.calltype; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN globalexpression.calltype IS 'Type of the call. Can be EXPRESSED or NOT_EXPRESSED';


--
-- TOC entry 208 (class 1259 OID 16408)
-- Name: globalexpression_globalexpressionid_seq; Type: SEQUENCE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE SEQUENCE globalexpression_globalexpressionid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;




--
-- TOC entry 3333 (class 0 OID 0)
-- Dependencies: 208
-- Name: globalexpression_globalexpressionid_seq; Type: SEQUENCE OWNED BY; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER SEQUENCE globalexpression_globalexpressionid_seq OWNED BY globalexpression.globalexpressionid;


--
-- TOC entry 210 (class 1259 OID 16414)
-- Name: species; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE species (
    speciesid integer NOT NULL,
    genus character varying(70) NOT NULL,
    species character varying(70) NOT NULL,
    speciescommonname character varying(70) DEFAULT ''::character varying,
    genomeversion character varying(50) NOT NULL,
    genomespeciesid integer DEFAULT 0 NOT NULL
);




--
-- TOC entry 3334 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN species.speciesid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN species.speciesid IS 'NCBI species taxon id';


--
-- TOC entry 3335 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN species.genus; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN species.genus IS 'Genus name';


--
-- TOC entry 3336 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN species.species; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN species.species IS 'Species name';


--
-- TOC entry 3337 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN species.speciescommonname; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN species.speciescommonname IS 'NCBI species common name';


--
-- TOC entry 3338 (class 0 OID 0)
-- Dependencies: 210
-- Name: COLUMN species.genomespeciesid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN species.genomespeciesid IS 'NCBI species taxon id used for mapping (0 if the same species)';


--
-- TOC entry 211 (class 1259 OID 16419)
-- Name: stage; Type: TABLE; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE TABLE stage (
    stageid character varying(20) NOT NULL,
    stagename character varying(255) NOT NULL,
    stagedescription text
);


--
-- TOC entry 3339 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN stage.stageid; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN stage.stageid IS 'Developmental stage id';


--
-- TOC entry 3340 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN stage.stagename; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN stage.stagename IS 'Developmental stage name';


--
-- TOC entry 3341 (class 0 OID 0)
-- Dependencies: 211
-- Name: COLUMN stage.stagedescription; Type: COMMENT; Schema: easybgee_v14_2; Owner: tmendesd
--

COMMENT ON COLUMN stage.stagedescription IS 'Developmental stage description';


--
-- TOC entry 3146 (class 2604 OID 16397)
-- Name: gene bgeegeneid; Type: DEFAULT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY gene ALTER COLUMN bgeegeneid SET DEFAULT nextval('gene_bgeegeneid_seq'::regclass);


--
-- TOC entry 3148 (class 2604 OID 16407)
-- Name: globalcond globalconditionid; Type: DEFAULT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalcond ALTER COLUMN globalconditionid SET DEFAULT nextval('globalcond_globalconditionid_seq'::regclass);


--
-- TOC entry 3149 (class 2604 OID 16413)
-- Name: globalexpression globalexpressionid; Type: DEFAULT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalexpression ALTER COLUMN globalexpressionid SET DEFAULT nextval('globalexpression_globalexpressionid_seq'::regclass);


--
-- TOC entry 3153 (class 2606 OID 16445)
-- Name: anatentity idx_16386_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY anatentity
    ADD CONSTRAINT idx_16386_primary PRIMARY KEY (anatentityid);


--
-- TOC entry 3156 (class 2606 OID 16444)
-- Name: gene idx_16394_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY gene
    ADD CONSTRAINT idx_16394_primary PRIMARY KEY (bgeegeneid);


--
-- TOC entry 3160 (class 2606 OID 16446)
-- Name: globalcond idx_16404_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalcond
    ADD CONSTRAINT idx_16404_primary PRIMARY KEY (globalconditionid);


--
-- TOC entry 3166 (class 2606 OID 16449)
-- Name: globalexpression idx_16410_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalexpression
    ADD CONSTRAINT idx_16410_primary PRIMARY KEY (bgeegeneid, globalconditionid);


--
-- TOC entry 3168 (class 2606 OID 16447)
-- Name: species idx_16414_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY species
    ADD CONSTRAINT idx_16414_primary PRIMARY KEY (speciesid);


--
-- TOC entry 3171 (class 2606 OID 16448)
-- Name: stage idx_16419_primary; Type: CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY stage
    ADD CONSTRAINT idx_16419_primary PRIMARY KEY (stageid);


--
-- TOC entry 3154 (class 1259 OID 16426)
-- Name: idx_16394_geneid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE UNIQUE INDEX idx_16394_geneid ON gene USING btree (geneid, speciesid);


--
-- TOC entry 3157 (class 1259 OID 16425)
-- Name: idx_16394_speciesid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE INDEX idx_16394_speciesid ON gene USING btree (speciesid);


--
-- TOC entry 3158 (class 1259 OID 16431)
-- Name: idx_16404_anatentityid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE UNIQUE INDEX idx_16404_anatentityid ON globalcond USING btree (anatentityid, stageid, speciesid);


--
-- TOC entry 3161 (class 1259 OID 16429)
-- Name: idx_16404_speciesid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE INDEX idx_16404_speciesid ON globalcond USING btree (speciesid);


--
-- TOC entry 3162 (class 1259 OID 16432)
-- Name: idx_16404_stageid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE INDEX idx_16404_stageid ON globalcond USING btree (stageid);


--
-- TOC entry 3163 (class 1259 OID 16436)
-- Name: idx_16410_globalconditionid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE INDEX idx_16410_globalconditionid ON globalexpression USING btree (globalconditionid);


--
-- TOC entry 3164 (class 1259 OID 16438)
-- Name: idx_16410_globalexpressionid; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE UNIQUE INDEX idx_16410_globalexpressionid ON globalexpression USING btree (globalexpressionid);


--
-- TOC entry 3169 (class 1259 OID 16434)
-- Name: idx_16414_species; Type: INDEX; Schema: easybgee_v14_2; Owner: tmendesd
--

CREATE UNIQUE INDEX idx_16414_species ON species USING btree (species, genus);


--
-- TOC entry 3172 (class 2606 OID 16450)
-- Name: gene gene_ibfk_1; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY gene
    ADD CONSTRAINT gene_ibfk_1 FOREIGN KEY (speciesid) REFERENCES species(speciesid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- TOC entry 3173 (class 2606 OID 16455)
-- Name: globalcond globalcond_ibfk_1; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalcond
    ADD CONSTRAINT globalcond_ibfk_1 FOREIGN KEY (anatentityid) REFERENCES anatentity(anatentityid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- TOC entry 3174 (class 2606 OID 16460)
-- Name: globalcond globalcond_ibfk_2; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalcond
    ADD CONSTRAINT globalcond_ibfk_2 FOREIGN KEY (stageid) REFERENCES stage(stageid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- TOC entry 3175 (class 2606 OID 16465)
-- Name: globalcond globalcond_ibfk_3; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalcond
    ADD CONSTRAINT globalcond_ibfk_3 FOREIGN KEY (speciesid) REFERENCES species(speciesid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- TOC entry 3176 (class 2606 OID 16470)
-- Name: globalexpression globalexpression_ibfk_1; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalexpression
    ADD CONSTRAINT globalexpression_ibfk_1 FOREIGN KEY (bgeegeneid) REFERENCES gene(bgeegeneid) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- TOC entry 3177 (class 2606 OID 16475)
-- Name: globalexpression globalexpression_ibfk_2; Type: FK CONSTRAINT; Schema: easybgee_v14_2; Owner: tmendesd
--

ALTER TABLE ONLY globalexpression
    ADD CONSTRAINT globalexpression_ibfk_2 FOREIGN KEY (globalconditionid) REFERENCES globalcond(globalconditionid) ON UPDATE RESTRICT ON DELETE CASCADE;


-- Completed on 2021-03-15 18:03:48 CET

--
-- PostgreSQL database dump complete
--

